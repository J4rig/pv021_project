#!/bin/bash

echo "#################"
echo "    COMPILING    "
echo "#################"

g++ -Wall -std=c++17 -O3 src/main.cpp -o network

echo "#################"
echo "     RUNNING     "
echo "#################"

nice -n 19 ./network

python3 ./evaluator/evaluate.py ./test_predictions.csv ./data/fashion_mnist_test_labels.csv